package com.sneproj.darrify.welcome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.sneproj.darrify.R;
import com.sneproj.darrify.emailAuth.EmailActivity;
import com.sneproj.darrify.phoneAuth.GenerateOTPActivity;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //Id
        Button email = findViewById(R.id.email);
        Button phone = findViewById(R.id.phone);

        //OnClick
        email.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), EmailActivity.class);
            startActivity(intent);
        });

        phone.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), GenerateOTPActivity.class);
            startActivity(intent);
        });

    }
}