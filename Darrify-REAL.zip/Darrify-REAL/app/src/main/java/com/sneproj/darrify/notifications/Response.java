package com.sneproj.darrify.notifications;

public class Response {
    private String success;
}
